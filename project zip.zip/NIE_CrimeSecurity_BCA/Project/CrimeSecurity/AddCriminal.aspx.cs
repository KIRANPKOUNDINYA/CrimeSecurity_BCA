﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CrimeSecurity
{
    public partial class AddCriminal : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            MyConnection obj = new MyConnection();
            Random rnd = new Random();
            int CriminalId = (rnd.Next(100000, 999999) + DateTime.Now.Second);
            string result = obj.AddCriminal(CriminalId, txtName.Text, int.Parse(txtAge.Text), ddlGender.SelectedItem.Text, txtMobileNo.Text,txtAadharNo.Text,txtPPNo.Text, txtAddress.Text);
            if (result == "1")
            {
                ddlGender.SelectedIndex = 0;
                txtName.Text = txtAge.Text = txtMobileNo.Text = txtAddress.Text =txtAadharNo.Text=txtPPNo.Text= "";
                Response.Redirect("CriminalData.aspx?CriminalId=" + CriminalId);
                //lblMsg.Text = "Criminal Added Successfully & " + Message;
                //lblMsg.ForeColor = System.Drawing.Color.Green;
            }

            else if (result == "0")
            {

                txtName.Text = txtAge.Text = txtMobileNo.Text = txtAddress.Text = "";
                lblMsg.Text = "Criminal Creation Error";
                lblMsg.ForeColor = System.Drawing.Color.Red;
            }
        }
    }
}