﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CrimeSecurity
{
    public partial class UserRegistration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            MyConnection obj = new MyConnection();
            Random rnd = new Random();
            int UserId = (rnd.Next(100000, 999999) + DateTime.Now.Second);
            string Password = (rnd.Next(1000, 9999) + DateTime.Now.Second).ToString();
            string result = obj.UserRegistration(UserId, txtName.Text, Password, txtMobileNo.Text, txtAadharNo.Text, txtAddress.Text);
            if (result == "1")
            {

                string Message = "Login Credentials User Id:" + UserId + " & Password:" + Password;
                txtName.Text = txtAadharNo.Text = txtMobileNo.Text = txtAddress.Text = "";
                lblMsg.Text = "User Registered Successfully & " + Message;
                lblMsg.ForeColor = System.Drawing.Color.Green;
            }
            else if (result == "2")
            {

                txtName.Text = txtAadharNo.Text = txtMobileNo.Text = txtAddress.Text = "";
                lblMsg.Text = "User Registered Already for Input Aadhar No";
                lblMsg.ForeColor = System.Drawing.Color.Red;
            }
            else if (result == "0")
            {

                txtName.Text = txtAadharNo.Text = txtMobileNo.Text = txtAddress.Text = "";
                lblMsg.Text = "User Registered Error";
                lblMsg.ForeColor = System.Drawing.Color.Red;
            }
        }

        protected void btnHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("index.aspx");
        }
    }
}