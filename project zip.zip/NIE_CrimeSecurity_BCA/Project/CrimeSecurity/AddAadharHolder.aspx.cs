﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using ZXing;
using System.Drawing;
using System.Drawing.Imaging;
using Amazon.S3;
using Amazon.S3.Model;
using System.IO;

namespace CrimeSecurity
{
    public partial class AddAadharHolder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        AmazonS3Client _s3ClientObj = null;
        static string filename;
        protected void btnSave_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int key = rnd.Next(1000, 9999);

            string AadharData = txtName.Text + "_" + txtSName.Text + "_" + ddlGender.SelectedItem.Text + "_" + txtDOB.Text + "_" + txtMobileNo.Text + "_" + txtAddress.Text;

            string EncryptData = AESCrypto.EncryptData(AadharData, key.ToString());

            string AadharNo = GenerateAadharNo();

            Random rnd1 = new Random();
            var QCwriter = new BarcodeWriter();
            QCwriter.Format = BarcodeFormat.QR_CODE;
            var result = QCwriter.Write(EncryptData);
            string v = rnd1.Next(1000, 9999).ToString();
            filename = key + "_" + v + ".jpg";

            string filepath = "~/DownloadFile/" + filename;
            var barcodeBitmap = new Bitmap(result);

            using (MemoryStream memory = new MemoryStream())
            {
                using (FileStream fs = new FileStream(Server.MapPath(filepath),
                   FileMode.Create, FileAccess.ReadWrite))
                {
                    barcodeBitmap.Save(memory, ImageFormat.Jpeg);
                    byte[] bytes = memory.ToArray();
                    fs.Write(bytes, 0, bytes.Length);
                }
            }



            ////Amazon AWS 
            _s3ClientObj = new AmazonS3Client("AKIA2PAQROQSWPFRCBEY", "tjrNzQwPc55MOxbAsyCfmqKeNjKqS+VJs4I7F+Ni", Amazon.RegionEndpoint.USEast1);
            PutBucketRequest p1 = new PutBucketRequest();
            p1.BucketName = "aadhar2023"; // reason: bucket name shared by millions so to avoid naming conflict , u can give anything u want
            _s3ClientObj.PutBucket(p1);

            PutObjectRequest _requestObj = new PutObjectRequest();
            _requestObj.BucketName = "aadhar2023";
            _requestObj.FilePath = Server.MapPath(filepath);
            PutObjectResponse _responseObj = _s3ClientObj.PutObject(_requestObj);

            if (_responseObj.HttpStatusCode == System.Net.HttpStatusCode.OK)
            {
                rnd = new Random();
                string Pfilename = txtName.Text + "_" + rnd.Next(1000, 9999) + Path.GetExtension(PhotoFile.FileName);
                string _filepath = "~/PhotoFiles/" + Pfilename;
                PhotoFile.SaveAs(Server.MapPath(_filepath));
                string FilePath = "aadhar2023" + "/" + filename;
                MyConnection obj = new MyConnection();
                string res = obj.CreateAadharHolder(AadharNo, FilePath, _filepath, key.ToString());
                if (res == "1")
                {
                    ddlGender.SelectedIndex = 0;
                    txtName.Text = txtSName.Text = txtDOB.Text = txtMobileNo.Text = txtAddress.Text = "";
                    lblMsg.Text = "Aadhar Register & Uploaded AWS Successfully";
                    lblMsg.ForeColor = System.Drawing.Color.Green;
                }

                else if (res == "0")
                {
                    ddlGender.SelectedIndex = 0;
                    txtName.Text = txtSName.Text = txtDOB.Text = txtMobileNo.Text = txtAddress.Text = "";
                    lblMsg.Text = "Aadhar Register Error";
                    lblMsg.ForeColor = System.Drawing.Color.Red;
                }
            }
        }

        public string GenerateAadharNo()
        {
            string aadharNo = "";
            Random r = new Random();
            for (int i = 1; i <= 3; i++)
            {
                for (int j = 1; j <= 4; j++)
                {
                    aadharNo+=r.Next(9);
                }
                //if (i <= 2) 
                //{
                //    aadharNo += "";
                //}
            }
            return aadharNo;

        }
    }
}