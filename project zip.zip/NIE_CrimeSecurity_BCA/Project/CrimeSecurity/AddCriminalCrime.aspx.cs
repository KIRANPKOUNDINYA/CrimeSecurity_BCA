﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace CrimeSecurity
{
    public partial class AddCriminalCrime : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                MyConnection obj = new MyConnection();
                DataTable tab = new DataTable();
                tab = obj.GetCrime(int.Parse(Session["UserId"].ToString()));
                ddlCrime.DataSource = tab;
                ddlCrime.DataTextField = "CrimeName";
                ddlCrime.DataValueField = "CrimeId";
                ddlCrime.DataBind();
                ddlCrime.Items.Insert(0, "--Select--");

                obj = new MyConnection();
                DataTable tabcm = new DataTable();
                tabcm = obj.GetCriminal_A();
                ddlCriminal.DataSource = tabcm;
                ddlCriminal.DataTextField = "CriminalId";
                ddlCriminal.DataValueField = "CriminalId";
                ddlCriminal.DataBind();
                ddlCriminal.Items.Insert(0, "--Select--");
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            MyConnection obj = new MyConnection();
            string res = obj.AddCriminalRecord(int.Parse(ddlCrime.SelectedItem.Value), int.Parse(ddlCriminal.SelectedItem.Value), txtDescription.Text);
            if (res == "1")
            {

                ddlCrime.SelectedIndex = 0;
                ddlCriminal.SelectedIndex = 0;
                txtDescription.Text = "";
                lblMsg.Text = "Criminal Crime added Successfully";
                lblMsg.ForeColor = System.Drawing.Color.Green;
            }

            else if (res == "0")
            {
                // txtName.Text = txtCrimePlace.Text = "";
                lblMsg.Text = "Criminal Crime Creation Error";
                lblMsg.ForeColor = System.Drawing.Color.Red;
            }
        }
    }
}