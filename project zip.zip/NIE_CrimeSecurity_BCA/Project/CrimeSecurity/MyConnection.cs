﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;
using System.Data;

namespace CrimeSecurity
{
    public class MyConnection
    {
        MySqlConnection con = null;
        MySqlCommand cmd = null;
        MySqlDataAdapter adp = null;

        public MyConnection()
        {
            con = new MySqlConnection("server=localhost;database=ecrimesecurity;user id=root;password=root;port=3306;");
            con.Open();
        }
        public string LoginVerify(string UserId, string Password)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string sql = "";
            string result = "";
            if (UserId == "Admin")
            {
                sql = string.Format("Select count(*) from applicationmanager where AMId='{0}' and Password='{1}'", UserId, Password);
                cmd.CommandText = sql;
                result = cmd.ExecuteScalar().ToString() + "_" + "Application Manager";
            }
            else
            {
                sql = string.Format("Select count(*) from aadharstaff where ASId={0} and Password='{1}'", UserId, Password);
                cmd.CommandText = sql;
                result = cmd.ExecuteScalar().ToString() + "_" + "Aadhar Officer";
                if (result.Split('_')[0] == "0")
                {
                    sql = string.Format("Select count(*) from passportstaff where PPSId={0} and Password='{1}'", UserId, Password);
                    cmd.CommandText = sql;
                    result = cmd.ExecuteScalar().ToString() + "_" + "Passport Staff";
                    if (result.Split('_')[0] == "0")
                    {
                        sql = string.Format("Select count(*) from policestationmaster where PoliceStationId={0} and Password='{1}'", UserId, Password);
                        cmd.CommandText = sql;
                        result = cmd.ExecuteScalar().ToString() + "_" + "Police Staff";
                        if (result.Split('_')[0] == "0")
                        {
                            sql = string.Format("Select count(*) from usermaster where UserId={0} and Password='{1}'", UserId, Password);
                            cmd.CommandText = sql;
                            result = cmd.ExecuteScalar().ToString() + "_" + "Public";
                        }
                    }
                }
            }
           
            return result;
        }
        
        public string ChangePassword(string UserId, string Password, string UserType)
        {

            cmd = new MySqlCommand();
            cmd.Connection = con;
            string result = "";
            string sql = "";
            if (UserType == "Application Manager")
            {
                sql = string.Format("Update applicationmanager set Password='{0}' where AMId='{1}'", Password, UserId);
            }
            else if (UserType == "Aadhar Officer")
            {
                sql = string.Format("Update aadharstaff set Password='{0}' where ASId={1}", Password, UserId);
            }
            else if (UserType == "Passport Staff")
            {
                sql = string.Format("Update passportstaff set Password='{0}' where PPSId={1}", Password, UserId);
            }
            else if (UserType == "Police Staff")
            {
                sql = string.Format("Update policestationmaster set Password='{0}' where PoliceStationId={1}", Password, UserId);
            }
            else if (UserType == "Public")
            {
                sql = string.Format("Update usermaster set Password='{0}' where UserId={1}", Password, UserId);
            }
            cmd.CommandText = sql;
            result = cmd.ExecuteNonQuery().ToString();
            con.Close();
            return result;
        }
        public string CreateCountry(string Name)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string sqlchk = string.Format("Select count(*) from countrymaster where CountryName='{0}'", Name);
            cmd.CommandText = sqlchk;
            int cnt = int.Parse(cmd.ExecuteScalar().ToString());
            string result = "";
            if (cnt == 0)
            {
                string sql = string.Format("insert into countrymaster(CountryName)values('{0}')", Name);
                cmd.CommandText = sql;
                result = cmd.ExecuteNonQuery().ToString();
            }
            else
            {
                result = "2";
            }
            con.Close();
            return result;
        }
        public DataTable GetCountry()
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string sql = string.Format("select * from countrymaster");
            cmd.CommandText = sql;
            adp = new MySqlDataAdapter(cmd);
            DataTable tab = new DataTable();
            adp.Fill(tab);
            con.Close();
            return tab;
        }
        public string CreateState(string StateName,int CountryId)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string sqlchk = string.Format("Select count(*) from statemaster where StateName='{0}'", StateName);
            cmd.CommandText = sqlchk;
            int cnt = int.Parse(cmd.ExecuteScalar().ToString());
            string result = "";
            if (cnt == 0)
            {
                string sql = string.Format("insert into statemaster(CountryId,StateName)values({0},'{1}')",CountryId, StateName);
                cmd.CommandText = sql;
                result = cmd.ExecuteNonQuery().ToString();
            }
            else
            {
                result = "2";
            }
            con.Close();
            return result;
        }
        public DataTable GetState_CountryId(int CountryId)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string sql = string.Format("select * from statemaster where CountryId={0}", CountryId);
            cmd.CommandText = sql;
            adp = new MySqlDataAdapter(cmd);
            DataTable tab = new DataTable();
            adp.Fill(tab);
            con.Close();
            return tab;
        }
        public string CreateCity(int StateId,string CityName)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string sqlchk = string.Format("Select count(*) from citymaster where CityName='{0}'", CityName);
            cmd.CommandText = sqlchk;
            int cnt = int.Parse(cmd.ExecuteScalar().ToString());
            string result = "";
            if (cnt == 0)
            {
                string sql = string.Format("insert into citymaster(StateId,CityName)values({0},'{1}')",StateId, CityName);
                cmd.CommandText = sql;
                result = cmd.ExecuteNonQuery().ToString();
            }
            else
            {
                result = "2";
            }
            con.Close();
            return result;
        }
        public DataTable GetCity_StateId(int StateId)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string sql = string.Format("select * from citymaster where StateId={0}", StateId);
            cmd.CommandText = sql;
            adp = new MySqlDataAdapter(cmd);
            DataTable tab = new DataTable();
            adp.Fill(tab);
            con.Close();
            return tab;
        }
        public string CreateArea(int CityId, string AreaName)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string sqlchk = string.Format("Select count(*) from areamaster where AreaName='{0}' and CityId={1}", AreaName,CityId);
            cmd.CommandText = sqlchk;
            int cnt = int.Parse(cmd.ExecuteScalar().ToString());
            string result = "";
            if (cnt == 0)
            {
                string sql = string.Format("insert into areamaster(CityId,AreaName)values({0},'{1}')", CityId, AreaName);
                cmd.CommandText = sql;
                result = cmd.ExecuteNonQuery().ToString();
            }
            else
            {
                result = "2";
            }
            con.Close();
            return result;
        }
        public DataTable GetArea_CityId(int CityId)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string sql = string.Format("select * from areamaster where CityId={0}", CityId);
            cmd.CommandText = sql;
            adp = new MySqlDataAdapter(cmd);
            DataTable tab = new DataTable();
            adp.Fill(tab);
            con.Close();
            return tab;
        }
        public string CreatePoliceStation(int PoliceStationId, int AreaId, string Name, string Password, string MobileNo, string EmailId, string Address)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string chksql = string.Format("Select count(*) from policestationmaster where AreaId={0}", AreaId);
            cmd.CommandText = chksql;
            string res = cmd.ExecuteScalar().ToString();
            string result = "";
            if (res == "0")
            {
                string sql = string.Format("insert into policestationmaster(PoliceStationId,AreaId,Name,Password,MobileNo,EmailId,Address)values({0},{1},'{2}','{3}','{4}','{5}','{6}')", PoliceStationId, AreaId, Name, Password, MobileNo, EmailId, Address);
                cmd.CommandText = sql;
                result = cmd.ExecuteNonQuery().ToString();
            }
            else
            {
                result = "2";
            }
            con.Close();
            return result;
        }
        public string CreateAadharStaff(int ASId, int CityId, string Name, string Password, string MobileNo, string EmailId, string Address)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string chksql = string.Format("Select count(*) from aadharstaff where EmailId='{0}'", EmailId);
            cmd.CommandText = chksql;
            string res = cmd.ExecuteScalar().ToString();
            string result = "";
            if (res == "0")
            {
                string sql = string.Format("insert into aadharstaff(ASId,CityId,Name,Password,MobileNo,EmailId,Address)values({0},{1},'{2}','{3}','{4}','{5}','{6}')", ASId, CityId, Name, Password, MobileNo, EmailId, Address);
                cmd.CommandText = sql;
                result = cmd.ExecuteNonQuery().ToString();
            }
            else
            {
                result = "2";
            }
            con.Close();
            return result;
        }
        public string CreateHigherOfficer(int HOId, string Name, string Password, string Role, string MobileNo, string EmailId, string Address)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string chksql = string.Format("Select count(*) from higherofficermaster where Role='{0}'", Role);
            cmd.CommandText = chksql;
            string res = cmd.ExecuteScalar().ToString();
            string result = "";
            if (res == "0")
            {
                string sql = string.Format("insert into higherofficermaster(HOId,Name,Password,Role,MobileNo,EmailId,Address)values({0},'{1}','{2}','{3}','{4}','{5}','{6}')", HOId, Name, Password, Role, MobileNo, EmailId, Address);
                cmd.CommandText = sql;
                result = cmd.ExecuteNonQuery().ToString();
            }
            else
            {
                result = "2";
            }
            con.Close();
            return result;
        }

        public string CreateAadharHolder(string AadharNo, string AWSFile, string PhotoFile,string Datakey)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string result = "";
            string sql = string.Format("insert into aadharmaster(AadharNo,AWSFilePath,PhotoPath,DataKey)values('{0}','{1}','{2}','{3}')", AadharNo, AWSFile, PhotoFile,Datakey);
            cmd.CommandText = sql;
            result = cmd.ExecuteNonQuery().ToString();
            con.Close();
            return result;
        }
        public string CreatePassportStaff(int PPSId, int CityId, string Name, string Password, string MobileNo, string EmailId, string Address)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string result = "";
            string sql = string.Format("insert into passportstaff(PPSId,CityId,Name,Password,MobileNo,EmailId,Address)values({0},{1},'{2}','{3}','{4}','{5}','{6}')", PPSId, CityId, Name, Password, MobileNo, EmailId, Address);
            cmd.CommandText = sql;
            result = cmd.ExecuteNonQuery().ToString();
            con.Close();
            return result;
        }
        public string AddForeignerPassport(int FPPNo, string Name, string LastName, int Age, string Gender, string MobileNo, string AMobileNo, string EmailId, string Address, string SAddress, string FilePath, string DateFrom, string DateTo)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string result = "";

            string chksql = string.Format("Select count(*) from foreignerpassport where FPPNo='{0}'", FPPNo);
            cmd.CommandText = chksql;
            string res = cmd.ExecuteScalar().ToString();

            if (res == "0")
            {

                string sql = string.Format("insert into foreignerpassport(FPPNo,Name,LastName,Age,Gender,MobileNo,AMobileNo,EmailId,Address,SAddress,DateFrom,DateTo,FilePath,Status)values({0},'{1}','{2}',{3},'{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','Active')", FPPNo, Name, LastName, Age, Gender, MobileNo, AMobileNo, EmailId, Address, SAddress, DateFrom, DateTo, FilePath);
                cmd.CommandText = sql;
                result = cmd.ExecuteNonQuery().ToString();

            }
            else
            {
                result = "2";
            }
            con.Close();
            return result;
        }
        public string AddCrime(int PSId, string CrimeName, string CrimePlace, string CrimeType, string Description)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string result = "";
            string sql = string.Format("insert into crimemaster(PSId,CrimeName,CrimePlace,CrimeType,Description,CrimeDate,Status)values({0},'{1}','{2}','{3}','{4}','{5}','Pending')", PSId, CrimeName, CrimePlace, CrimeType, Description, DateTime.Now);
            cmd.CommandText = sql;
            result = cmd.ExecuteNonQuery().ToString();

            con.Close();
            return result;
        }
        public DataTable GetCrime(int PoliceStationId)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string sql = string.Format("Select * from crimemaster where PSId={0} and (Status='Pending' or Status='Process')", PoliceStationId);
            cmd.CommandText = sql;
            adp = new MySqlDataAdapter(cmd);
            DataTable tab = new DataTable();
            adp.Fill(tab);
            con.Close();
            return tab;
        }
        public string CreateTable_CSL(int CrimeId, string LogDate, string Key, string FilePath)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string result = "";
            string sqlup = string.Format("Update crimemaster set Status='Process' where CrimeId={0}", CrimeId);
            cmd.CommandText = sqlup;
            result = cmd.ExecuteNonQuery().ToString();

            string sql = string.Format("insert into crimelog(CId,LogDate,CLHV,FilePath)values({0},'{1}','{2}','{3}')", CrimeId, LogDate, Key, FilePath);
            cmd.CommandText = sql;
            result = cmd.ExecuteNonQuery().ToString();
            con.Close();
            return result;
        }
        public DataTable GetForeignerDetails(int FPPNo)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string sqlfsd = string.Format("Select * from foreignerpassport where FPPNo={0}", FPPNo);
            cmd.CommandText = sqlfsd;
            adp = new MySqlDataAdapter(cmd);
            DataTable tab = new DataTable();
            adp.Fill(tab);
            con.Close();
            return tab;
        }

        public string UserRegistration(int UserId, string Name, string Password, string MobileNo, string AadharNo, string Address)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string result = "";

            string chksql = string.Format("Select count(*) from usermaster where AadharNo='{0}'", AadharNo);
            cmd.CommandText = chksql;
            string res = cmd.ExecuteScalar().ToString();

            if (res == "0")
            {
                string sql = string.Format("insert into usermaster(UserId,Name,Password,MobileNo,AadharNo,Address)values({0},'{1}','{2}','{3}','{4}','{5}')", UserId, Name, Password, MobileNo, AadharNo, Address);
                cmd.CommandText = sql;
                result = cmd.ExecuteNonQuery().ToString();
            }
            else
            {
                result = "2";
            }
            con.Close();
            return result;
        }

        public string UserRequest(int UserId,string AadharNo,string Reason)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string result = "";

            string chksql = string.Format("Select count(*) from userrequest where ReqAadharNo='{0}' and UserId={1} and Status='Pending'", AadharNo, UserId);
            cmd.CommandText = chksql;
            string res = cmd.ExecuteScalar().ToString();

            if (res == "0")
            {
                string sql = string.Format("insert into userrequest(UserId,ReqAadharNo,ReqReason,ReqDate,Status)values({0},'{1}','{2}','{3}','Pending')", UserId, AadharNo, Reason, DateTime.Now.ToString("dd/MM/yyyy"));
                cmd.CommandText = sql;
                result = cmd.ExecuteNonQuery().ToString();
            }
            else
            {
                result = "2";
            }
            con.Close();
            return result;
        }

        public DataTable GetAadharData()
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string sqlfsd = string.Format("Select usermaster.UserId,userrequest.ReqId,usermaster.Name,userrequest.ReqDate,userrequest.ReqReason from userrequest inner join usermaster on usermaster.UserId=userrequest.UserId where userrequest.Status='Pending'");
            cmd.CommandText = sqlfsd;
            adp = new MySqlDataAdapter(cmd);
            DataTable tab = new DataTable();
            adp.Fill(tab);
            con.Close();
            return tab;
        }

        public DataTable GetUserDetails(int UserId)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string sqlfsd = string.Format("select * from usermaster where UserId={0}",UserId);
            cmd.CommandText = sqlfsd;
            adp = new MySqlDataAdapter(cmd);
            DataTable tab = new DataTable();
            adp.Fill(tab);
            con.Close();
            return tab;
        }

        public DataTable GetUserAadharAWS(string AadharNo)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string sqlfsd = string.Format("select * from aadharmaster where AadharNo='{0}'", AadharNo);
            cmd.CommandText = sqlfsd;
            adp = new MySqlDataAdapter(cmd);
            DataTable tab = new DataTable();
            adp.Fill(tab);
            con.Close();
            return tab;
        }

        public string AadharReq_AR(int ReqId, string Status)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string result = "";
            string sqlup = string.Format("Update userrequest set Status='{0}' where ReqId={1}", Status,ReqId);
            cmd.CommandText = sqlup;
            result = cmd.ExecuteNonQuery().ToString();
            con.Close();
            return result;
        }

        public DataTable GetUserRequest_Aadhar(int UserId)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string sqlfsd = string.Format("select * from userrequest where UserId={0} and status='Approve'", UserId);
            cmd.CommandText = sqlfsd;
            adp = new MySqlDataAdapter(cmd);
            DataTable tab = new DataTable();
            adp.Fill(tab);
            con.Close();
            return tab;
        }

        public string UpdateAadharAddress(string AadharNo, string FilePath,string Key,string OldAddress)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string result = "";
            string sqlup = string.Format("Update aadharmaster set AWSFilePath='{0}',DataKey='{1}' where AadharNo='{2}'", FilePath, Key,AadharNo);
            cmd.CommandText = sqlup;
            result = cmd.ExecuteNonQuery().ToString();

            string sql = string.Format("insert into aadharaddress(AadharNo,OldAddress,DateModify)values('{0}','{1}','{2}')",AadharNo,OldAddress,DateTime.Now.ToString("dd/MM/yyyy"));
            cmd.CommandText = sql;
            result = cmd.ExecuteNonQuery().ToString();

            con.Close();
            return result;
        }

        public DataTable GetAadhar_Address(string AadharNo)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string sqlfsd = string.Format("select * from aadharaddress where AadharNo='{0}'", AadharNo);
            cmd.CommandText = sqlfsd;
            adp = new MySqlDataAdapter(cmd);
            DataTable tab = new DataTable();
            adp.Fill(tab);
            con.Close();
            return tab;
        }

        public string AddCriminal(int CriminalId, string CriminalName, int Age, string Gender, string MobileNo,string AadharNo,string PassportNo, string Address)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string result = "";
            string sql = string.Format("insert into criminaldetails(CriminalId,CriminalName,Age,Gender,MobileNo,AadharNo,PassportNo,Address,Status)values({0},'{1}',{2},'{3}','{4}','{5}','{6}','{7}','Active')", CriminalId, CriminalName, Age, Gender, MobileNo,AadharNo,PassportNo, Address);
            cmd.CommandText = sql;
            result = cmd.ExecuteNonQuery().ToString();
            con.Close();
            return result;
        }
        public string AddCriminalData(int CriminalId, string Eyecolor, string FingerPrint, string Height, string Weight, string PhotoPath)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string result = "";
            string sql = string.Format("insert into criminaldata(CriminalId,Eyecolor,FingerPrint,Height,Weight,PhotoPath)values({0},'{1}','{2}','{3}','{4}','{5}')", CriminalId, Eyecolor, FingerPrint, Height, Weight, PhotoPath);
            cmd.CommandText = sql;
            result = cmd.ExecuteNonQuery().ToString();
            con.Close();
            return result;
        }
        public DataTable GetCriminal_A()
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string sqlfsd = string.Format("select * from criminaldetails where Status='Active'");
            cmd.CommandText = sqlfsd;
            adp = new MySqlDataAdapter(cmd);
            DataTable tab = new DataTable();
            adp.Fill(tab);
            con.Close();
            return tab;
        }
        public string AddCriminalRecord(int CrimeId, int CriminalId, string Description)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string result = "";
            string sql = string.Format("insert into criminalcrimerecord(CrimeId,CriminalId,Description)values({0},{1},'{2}')", CrimeId, CriminalId, Description);
            cmd.CommandText = sql;
            result = cmd.ExecuteNonQuery().ToString();
            con.Close();
            return result;
        }
        public DataTable GetCriminal_data(string SearchCriminal)
        {
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string sqlfsd = string.Format("select criminaldetails.CriminalName,criminaldetails.Age,criminaldetails.Gender,criminaldetails.MobileNo,criminaldetails.AadharNo,criminaldetails.Address,criminaldata.Eyecolor,criminaldata.FingerPrint,criminaldata.Height,criminaldata.weight,criminaldata.PhotoPath,criminalcrimerecord.Description from criminaldetails inner join criminaldata on criminaldetails.CriminalId=criminaldata.CriminalId inner join criminalcrimerecord on criminaldetails.CriminalId=criminalcrimerecord.CriminalId where criminaldetails.AadharNo='{0}' or criminaldetails.PassportNo='{1}'", SearchCriminal, SearchCriminal);
            cmd.CommandText = sqlfsd;
            adp = new MySqlDataAdapter(cmd);
            DataTable tab = new DataTable();
            adp.Fill(tab);
            con.Close();
            return tab;
        }
    }
}