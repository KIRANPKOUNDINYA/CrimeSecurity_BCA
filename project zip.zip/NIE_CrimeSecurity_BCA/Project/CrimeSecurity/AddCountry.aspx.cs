﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CrimeSecurity
{
    public partial class AddCountry : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            MyConnection obj = new MyConnection();
            string result = obj.CreateCountry(txtCName.Text);
            if (result == "1")
            {
                txtCName.Text = "";
                lblMsg.Text = "Country Added Successfully";
                lblMsg.ForeColor = System.Drawing.Color.Green;
            }
            else if (result == "2")
            {
                txtCName.Text = "";
                lblMsg.Text = "Country Added Already";
                lblMsg.ForeColor = System.Drawing.Color.Red;
            }
            else if (result == "0")
            {
                txtCName.Text = "";
                lblMsg.Text = "Country Creation Error";
                lblMsg.ForeColor = System.Drawing.Color.Red;
            }
        }
    }
}