﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace CrimeSecurity
{
    public partial class AddState : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                MyConnection obj = new MyConnection();
                DataTable tab = new DataTable();
                tab = obj.GetCountry();
                ddlCountry.DataSource = tab;
                ddlCountry.DataTextField = "CountryName";
                ddlCountry.DataValueField = "CountryId";
                ddlCountry.DataBind();
                ddlCountry.Items.Insert(0, "--Select--");
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {

            MyConnection obj = new MyConnection();
            string result = obj.CreateState(txtStateName.Text, int.Parse(ddlCountry.SelectedItem.Value));
            if (result == "1")
            {
                ddlCountry.SelectedIndex = 0;
                txtStateName.Text = "";
                lblMsg.Text = "State Added Successfully";
                lblMsg.ForeColor = System.Drawing.Color.Green;
            }
            else if (result == "2")
            {
                ddlCountry.SelectedIndex = 0;
                txtStateName.Text = "";
                lblMsg.Text = "State Added Already";
                lblMsg.ForeColor = System.Drawing.Color.Red;
            }
            else if (result == "0")
            {
                ddlCountry.SelectedIndex = 0;
                txtStateName.Text = "";
                lblMsg.Text = "State Creation Error";
                lblMsg.ForeColor = System.Drawing.Color.Red;
            }
        }
    }
}