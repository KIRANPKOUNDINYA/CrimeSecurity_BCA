﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Amazon.S3;
using Amazon.S3.Model;

namespace CrimeSecurity
{
    public partial class PSViewForeignerPP : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btn_Click(object sender, EventArgs e)
        {
            MyConnection obj = new MyConnection();
            DataTable tab = new DataTable();
            tab = obj.GetForeignerDetails(int.Parse(txtFPPNo.Text));
            if (tab.Rows.Count > 0)
            {
                DataList1.DataSource = tab;
                DataList1.DataBind();
                lblMsg.Text = "";
            }
            else
            {
                lblMsg.Text = "No Record Found!!!";
                lblMsg.ForeColor = System.Drawing.Color.Red;
            }
        }
        AmazonS3Client _s3ClientObj = null;
        protected void lnkDownload_Click(object sender, EventArgs e)
        {
            _s3ClientObj = new AmazonS3Client("AKIA2PAQROQSWPFRCBEY", "tjrNzQwPc55MOxbAsyCfmqKeNjKqS+VJs4I7F+Ni", Amazon.RegionEndpoint.USEast1);

            LinkButton lnk = (LinkButton)sender;
            string res = lnk.CommandArgument.ToString();
            string fname = "~/DownloadFile/" + res.Split('/')[1];
            GetObjectResponse _responseObj = _s3ClientObj.GetObject(new GetObjectRequest() { BucketName = res.Split('/')[0], Key = res.Split('/')[1] });
            _responseObj.WriteResponseStreamToFile(Server.MapPath(fname));
            System.Diagnostics.Process.Start(Server.MapPath(fname));
        }
    }
}