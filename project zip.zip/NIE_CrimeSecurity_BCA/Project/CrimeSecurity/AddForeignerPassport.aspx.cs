﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Net.Mail;
using iTextSharp.text.pdf;
using iTextSharp.text;
using System.Configuration;
using Amazon.S3;
using Amazon.S3.Model;

namespace CrimeSecurity
{
    public partial class AddForeignerPassport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        AmazonS3Client _s3ClientObj = null;
        protected void btnSave_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            string Pfilename = txtFPPNo.Text + "_" + rnd.Next(1000, 9999) + Path.GetExtension(PhotoFile.FileName);
            string filepath = "~/PhotoFiles/" + Pfilename;
            PhotoFile.SaveAs(Server.MapPath(filepath));

            string filename = "~/PassPortFiles/";
            if (Directory.Exists(Server.MapPath(filename)) == false)
            {
                Directory.CreateDirectory(Server.MapPath(filename));
            }
            filename = txtFPPNo.Text + "_N_" + rnd.Next(2000) + DateTime.Now.Second + ".pdf";

            FileStream fs = new FileStream(Server.MapPath("~/PassPortFiles/" + filename), FileMode.Create, FileAccess.Write, FileShare.None);
            iTextSharp.text.Rectangle rec2 = new iTextSharp.text.Rectangle(PageSize.A4);
            Document doc = new Document(rec2, 36, 72, 20, 180);  // page size , left , right , top , bottom
            PdfWriter writer = PdfWriter.GetInstance(doc, fs);
            doc.Open();

            PdfContentByte cb = writer.DirectContent;
            cb.SetLineWidth(2.0f);   // Make a bit thicker than 1.0 default
            cb.SetGrayStroke(0.95f); // 1 = black, 0 = white
            cb.MoveTo(20, 30);
            cb.LineTo(400, 30);
            cb.Stroke();


            PdfPTable table = new PdfPTable(5);

            string imageURL = Server.MapPath("~/images/PP_Logo.jpg");
            iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(imageURL);
            PdfPCell cell = new PdfPCell(new Phrase("PASSPORT" + "\n(" + "Foreigner" + ")\n"));
            cell.Colspan = 4;
            cell.HorizontalAlignment = 1;
            cell.Border = 0;
            table.AddCell(jpg);
            table.AddCell(cell);
            table.DefaultCell.Border = 0;

            PdfPCell cellName = new PdfPCell(new Phrase("Name:" + txtName.Text));
            cellName.Colspan = 2;
            cellName.Border = 0;
            table.AddCell(cellName);
            PdfPCell cellLName = new PdfPCell(new Phrase("Last Name:" + txtLName.Text));
            cellLName.Colspan = 2;
            cellLName.Border = 0;
            table.AddCell(cellLName);
            PdfPCell cellimg = new PdfPCell(new Phrase());
            string imageuser = Server.MapPath(filepath);
            iTextSharp.text.Image jpguser = iTextSharp.text.Image.GetInstance(imageuser);
            cellimg.AddElement(jpguser);
            cellimg.Rowspan = 4;
            table.AddCell(cellimg);
            table.DefaultCell.Border = 0;

            PdfPCell cellAge = new PdfPCell(new Phrase("Age:" + txtAge.Text));
            cellAge.Colspan = 2;
            cellAge.Border = 0;
            table.AddCell(cellAge);
            PdfPCell cellGender = new PdfPCell(new Phrase("Gender:" + ddlGender.SelectedItem.Text));
            cellGender.Colspan = 2;
            cellGender.Border = 0;
            table.AddCell(cellGender);
            table.DefaultCell.Border = 0;

            PdfPCell cellCity = new PdfPCell(new Phrase("MobileNo:" + txtMobileNo.Text));
            cellCity.Colspan = 2;
            cellCity.Border = 0;
            table.AddCell(cellCity);
            PdfPCell cellAddress = new PdfPCell(new Phrase("Address:" + txtAddress.Text));
            cellAddress.Colspan = 2;
            cellAddress.Border = 0;
            table.AddCell(cellAddress);
            table.DefaultCell.Border = 0;

            string DateFrom = txtDateForm.Text;
            string DateTo = txtDateTo.Text;
            PdfPCell cellDateFrom = new PdfPCell(new Phrase("DateFrom:" + DateFrom));
            cellDateFrom.Colspan = 2;
            cellDateFrom.Border = 0;
            table.AddCell(cellDateFrom);
            PdfPCell cellDateTo = new PdfPCell(new Phrase("DateTo:" + DateTo));
            cellDateTo.Colspan = 2;
            cellDateTo.Border = 0;
            table.AddCell(cellDateTo);

            table.DefaultCell.Border = 0;

            doc.Add(table);

            string Space = "\n\n";
            Paragraph ReasonSpace = new Paragraph(Space);
            doc.Add(ReasonSpace);


            string Space1 = "\n";
            Paragraph ReasonSpace1 = new Paragraph(Space1);
            doc.Add(ReasonSpace1);

            doc.Close();

            ////Amazon AWS 

            _s3ClientObj = new AmazonS3Client("AKIA2PAQROQSWPFRCBEY", "tjrNzQwPc55MOxbAsyCfmqKeNjKqS+VJs4I7F+Ni", Amazon.RegionEndpoint.USEast1);
            PutBucketRequest p1 = new PutBucketRequest();
            p1.BucketName = txtName.Text.ToLower() + txtFPPNo.Text; // reason: bucket name shared by millions so to avoid naming conflict , u can give anything u want
            _s3ClientObj.PutBucket(p1);

            PutObjectRequest _requestObj = new PutObjectRequest();
            _requestObj.BucketName = txtName.Text.ToLower() + txtFPPNo.Text;
            _requestObj.FilePath = Server.MapPath("~/PassPortFiles/" + filename);
            PutObjectResponse _responseObj = _s3ClientObj.PutObject(_requestObj);

            if (_responseObj.HttpStatusCode == System.Net.HttpStatusCode.OK)
            {
                MyConnection obj = new MyConnection();
                string amzpath = txtName.Text.ToLower() + txtFPPNo.Text + "/" + filename;
                string res = obj.AddForeignerPassport(int.Parse(txtFPPNo.Text), txtName.Text, txtLName.Text, int.Parse(txtAge.Text), ddlGender.SelectedItem.Text, txtMobileNo.Text, txtAMobileNo.Text, txtEmailId.Text, txtAddress.Text, txtSAddress.Text, amzpath, DateFrom, DateTo);
                if (res == "1")
                {
                    txtFPPNo.Text = "";
                    ddlGender.SelectedIndex = 0;
                    txtName.Text = txtLName.Text = txtAge.Text = txtMobileNo.Text = txtEmailId.Text = txtAMobileNo.Text = txtAddress.Text = txtSAddress.Text = txtDateForm.Text = txtDateTo.Text = "";
                    lblMsg.Text = "Passport Generated Successfully";
                    lblMsg.ForeColor = System.Drawing.Color.Green;
                }

                else if (res == "2")
                {
                    txtFPPNo.Text = "";
                    ddlGender.SelectedIndex = 0;
                    txtName.Text = txtLName.Text = txtAge.Text = txtMobileNo.Text = txtEmailId.Text = txtAMobileNo.Text = txtAddress.Text = txtSAddress.Text = txtDateForm.Text = txtDateTo.Text = "";
                    lblMsg.Text = "Passport Generate Error";
                    lblMsg.ForeColor = System.Drawing.Color.Red;
                }
            }
        }
    }
}