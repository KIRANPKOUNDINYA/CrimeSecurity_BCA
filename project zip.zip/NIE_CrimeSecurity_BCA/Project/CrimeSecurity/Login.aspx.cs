﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CrimeSecurity
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("index.aspx");
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            MyConnection obj = new MyConnection();
            string result = obj.LoginVerify(txtUserId.Text, txtPassword.Text);
            if (result.Split('_')[0] == "1")
            {
                Session["UserId"] = txtUserId.Text;
                Session["Password"] = txtPassword.Text;
                Session["UserType"] = result.Split('_')[1];
                switch (result.Split('_')[1])
                {
                    case "Application Manager":
                        Response.Redirect("AMHome.aspx");
                        break;
                    case "Aadhar Officer":
                        Response.Redirect("ASHome.aspx");
                        break;
                    case "Passport Staff":
                        Response.Redirect("PassportHome.aspx");
                        break;
                    case "Police Staff":
                        Response.Redirect("PoliceHome.aspx");
                        break;
                    case "Public":
                        Response.Redirect("UserHome.aspx");
                        break;
                }
            }
            else
            {
                lblMsg.Text = "Invalid UserId/Password";
                lblMsg.ForeColor = System.Drawing.Color.Red;
            }
        }
    }
}