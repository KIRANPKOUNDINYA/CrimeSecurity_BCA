﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace CrimeSecurity
{
    public partial class AddCity : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                MyConnection obj = new MyConnection();
                DataTable tab = new DataTable();
                tab = obj.GetCountry();
                ddlCountry.DataSource = tab;
                ddlCountry.DataTextField = "CountryName";
                ddlCountry.DataValueField = "CountryId";
                ddlCountry.DataBind();
                ddlCountry.Items.Insert(0, "--Select--");
            }
        }

        protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                MyConnection obj = new MyConnection();
                DataTable tab = new DataTable();
                tab = obj.GetState_CountryId(int.Parse(ddlCountry.SelectedItem.Value));
                ddlState.DataSource = tab;
                ddlState.DataTextField = "StateName";
                ddlState.DataValueField = "StateId";
                ddlState.DataBind();
                ddlState.Items.Insert(0, "--Select--");
            }
            catch
            { }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            MyConnection obj = new MyConnection();
            string result = obj.CreateCity(int.Parse(ddlState.SelectedItem.Value),txtCityName.Text);
            if (result == "1")
            {
                ddlCountry.SelectedIndex = 0;
                ddlState.SelectedIndex = 0;
                txtCityName.Text = "";
                lblMsg.Text = "City Added Successfully";
                lblMsg.ForeColor = System.Drawing.Color.Green;
            }
            else if (result == "2")
            {
                ddlCountry.SelectedIndex = 0;
                ddlState.SelectedIndex = 0;
                txtCityName.Text = "";
                lblMsg.Text = "City Added Already";
                lblMsg.ForeColor = System.Drawing.Color.Red;
            }
            else if (result == "0")
            {
                ddlCountry.SelectedIndex = 0;
                ddlState.SelectedIndex = 0;
                txtCityName.Text = "";
                lblMsg.Text = "City Creation Error";
                lblMsg.ForeColor = System.Drawing.Color.Red;
            }
        }

        
    }
}