﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CrimeSecurity
{
    public partial class UserRequest : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            MyConnection obj = new MyConnection();
            string result = obj.UserRequest(int.Parse(Session["UserId"].ToString()), txtReqAadharNo.Text, txtReason.Text);
            if (result == "1")
            {
                txtReqAadharNo.Text = txtReason.Text = "";
                lblMsg.Text = "Aadhar Card Data Request Successfully";
                lblMsg.ForeColor = System.Drawing.Color.Green;
            }
            else if(result=="2")
            {
                lblMsg.Text="Aadhar Card Data Request Already!!..";
                lblMsg.ForeColor=System.Drawing.Color.Red;
            }
            else
            {
                lblMsg.Text = "Aadhar Card Data Request Error!!..";
                lblMsg.ForeColor = System.Drawing.Color.Red;
            }
        }
    }
}