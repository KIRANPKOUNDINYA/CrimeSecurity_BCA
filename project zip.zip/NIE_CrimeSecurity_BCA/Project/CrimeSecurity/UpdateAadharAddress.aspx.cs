﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using ZXing;
using System.Drawing;
using System.Drawing.Imaging;
using Amazon.S3;
using Amazon.S3.Model;
using System.Text;
using System.IO;

namespace CrimeSecurity
{
    public partial class UpdateAadharAddress : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        AmazonS3Client _s3ClientObj = null;
        static string filename;

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            MyConnection obj = new MyConnection();
            DataTable tabaws = new DataTable();
            tabaws = obj.GetUserAadharAWS(txtAadharNo.Text);
            if (tabaws.Rows.Count > 0)
            {
                _s3ClientObj = new AmazonS3Client("AKIA2PAQROQSWPFRCBEY", "tjrNzQwPc55MOxbAsyCfmqKeNjKqS+VJs4I7F+Ni", Amazon.RegionEndpoint.USEast1);
                string fname = "~/DownloadFile/" + tabaws.Rows[0]["AWSFilePath"].ToString().Split('/')[1];
                if (File.Exists(Server.MapPath(fname)))
                {
                    File.Delete(Server.MapPath(fname));
                }
                GetObjectResponse _responseObj = _s3ClientObj.GetObject(new GetObjectRequest() { BucketName = tabaws.Rows[0]["AWSFilePath"].ToString().Split('/')[0], Key = tabaws.Rows[0]["AWSFilePath"].ToString().Split('/')[1] });
                _responseObj.WriteResponseStreamToFile(Server.MapPath(fname));

                _s3ClientObj.DeleteObject(new Amazon.S3.Model.DeleteObjectRequest() { BucketName = tabaws.Rows[0]["AWSFilePath"].ToString().Split('/')[0], Key = tabaws.Rows[0]["AWSFilePath"].ToString().Split('/')[1] });
                var QCreader = new BarcodeReader();
                string QCfilename = Path.Combine(Server.MapPath(fname));
                var QCresult = QCreader.Decode(new Bitmap(QCfilename));

                string AadharData = AESCryptoClass.Decrypt(QCresult.Text, tabaws.Rows[0]["DataKey"].ToString());

                txtName.Text = AadharData.Split('_')[0];
                txtOldAddress.Text = AadharData.Split('_')[5];

                string NewData = AadharData.Split('_')[0] + "_" + AadharData.Split('_')[1] + "_" + AadharData.Split('_')[2] + "_" + AadharData.Split('_')[3] + "_" + AadharData.Split('_')[4];
                Session["NewData"] = NewData;
                
            
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            

            Random rnd = new Random();
            int key = rnd.Next(1000, 9999);

            string EncryptData = AESCrypto.EncryptData(Session["NewData"].ToString()+"_"+txtAddress.Text, key.ToString());

            Random rnd1 = new Random();
            var QCwriter = new BarcodeWriter();
            QCwriter.Format = BarcodeFormat.QR_CODE;
            var result = QCwriter.Write(EncryptData);
            string v = rnd1.Next(1000, 9999).ToString();
            filename = key + "_" + v + ".jpg";

            string filepath = "~/DownloadFile/" + filename;
            var barcodeBitmap = new Bitmap(result);

            using (MemoryStream memory = new MemoryStream())
            {
                using (FileStream fs = new FileStream(Server.MapPath(filepath),
                   FileMode.Create, FileAccess.ReadWrite))
                {
                    barcodeBitmap.Save(memory, ImageFormat.Jpeg);
                    byte[] bytes = memory.ToArray();
                    fs.Write(bytes, 0, bytes.Length);
                }
            }



            ////Amazon AWS 
            _s3ClientObj = new AmazonS3Client("AKIA2PAQROQSWPFRCBEY", "tjrNzQwPc55MOxbAsyCfmqKeNjKqS+VJs4I7F+Ni", Amazon.RegionEndpoint.USEast1);
            PutBucketRequest p1 = new PutBucketRequest();
            p1.BucketName = "aadhar2023"; // reason: bucket name shared by millions so to avoid naming conflict , u can give anything u want
            _s3ClientObj.PutBucket(p1);

            PutObjectRequest _requestObj = new PutObjectRequest();
            _requestObj.BucketName = "aadhar2023";
            _requestObj.FilePath = Server.MapPath(filepath);
            PutObjectResponse responseObj = _s3ClientObj.PutObject(_requestObj);

            if (responseObj.HttpStatusCode == System.Net.HttpStatusCode.OK)
            {
                rnd = new Random();

                string FilePath = "aadhar2023" + "/" + filename;
                MyConnection obj = new MyConnection();
                string res = obj.UpdateAadharAddress(txtAadharNo.Text, FilePath, key.ToString(),txtOldAddress.Text);
                if (res == "1")
                {

                    txtName.Text = txtOldAddress.Text = txtAddress.Text = "";
                    lblMsg.Text = "Aadhar Updated & Uploaded AWS Successfully";
                    lblMsg.ForeColor = System.Drawing.Color.Green;
                }

                else if (res == "0")
                {
                    txtName.Text = txtOldAddress.Text = txtAddress.Text = "";
                    lblMsg.Text = "Aadhar Updation Error";
                    lblMsg.ForeColor = System.Drawing.Color.Red;
                }
            }
        }
    }
}