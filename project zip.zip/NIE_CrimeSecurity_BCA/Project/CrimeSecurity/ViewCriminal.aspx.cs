﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using ZXing;
using System.Drawing;
using System.Drawing.Imaging;
using Amazon.S3;
using Amazon.S3.Model;
using System.Text;
using System.IO;

namespace CrimeSecurity
{
    public partial class ViewCriminal : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Panel1.Visible = false;
            }
        }
        AmazonS3Client _s3ClientObj = null;
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            MyConnection obj = new MyConnection();
            DataTable tab = new DataTable();
            tab = obj.GetCriminal_data(txtCriminal.Text);

            if (tab.Rows.Count > 0)
            {
                DataList1.DataSource = tab;
                DataList1.DataBind();
                Panel1.Visible = true;
                lblMsg.Text = "";
                if (tab.Rows[0]["AadharNo"].ToString() != "0")
                {
                    DataTable tabaws = new DataTable();
                    tabaws = obj.GetUserAadharAWS(tab.Rows[0]["AadharNo"].ToString());

                    _s3ClientObj = new AmazonS3Client("AKIA2PAQROQSWPFRCBEY", "tjrNzQwPc55MOxbAsyCfmqKeNjKqS+VJs4I7F+Ni", Amazon.RegionEndpoint.USEast1);
                    string fname = "~/DownloadFile/" + tabaws.Rows[0]["AWSFilePath"].ToString().Split('/')[1];
                    if (File.Exists(Server.MapPath(fname)))
                    {
                        File.Delete(Server.MapPath(fname));
                    }
                    GetObjectResponse _responseObj = _s3ClientObj.GetObject(new GetObjectRequest() { BucketName = tabaws.Rows[0]["AWSFilePath"].ToString().Split('/')[0], Key = tabaws.Rows[0]["AWSFilePath"].ToString().Split('/')[1] });
                    _responseObj.WriteResponseStreamToFile(Server.MapPath(fname));


                    var QCreader = new BarcodeReader();
                    string QCfilename = Path.Combine(Server.MapPath(fname));
                    var QCresult = QCreader.Decode(new Bitmap(QCfilename));

                    string AadharData = AESCryptoClass.Decrypt(QCresult.Text, tabaws.Rows[0]["DataKey"].ToString());

                    Table1.Controls.Clear();

                    TableRow AWShr = new TableRow();
                    TableHeaderCell AWShc1 = new TableHeaderCell();
                    TableHeaderCell AWShc2 = new TableHeaderCell();
                    TableHeaderCell AWShc3 = new TableHeaderCell();
                    TableHeaderCell AWShc4 = new TableHeaderCell();
                    TableHeaderCell AWShc5 = new TableHeaderCell();
                    TableHeaderCell AWShc6 = new TableHeaderCell();
                    TableHeaderCell AWShc7 = new TableHeaderCell();

                    AWShc1.Text = "Sl No";
                    AWShr.Cells.Add(AWShc1);
                    AWShc2.Text = "Name";
                    AWShr.Cells.Add(AWShc2);
                    AWShc3.Text = "Gender";
                    AWShr.Cells.Add(AWShc3);
                    AWShc4.Text = "DOB";
                    AWShr.Cells.Add(AWShc4);
                    AWShc5.Text = "MobileNo";
                    AWShr.Cells.Add(AWShc5);
                    AWShc6.Text = "Address";
                    AWShr.Cells.Add(AWShc6);
                    AWShc7.Text = "Image";
                    AWShr.Cells.Add(AWShc7);

                    Table1.Rows.Add(AWShr);
                    TableRow AWSrow = new TableRow();

                    Label lblASlNo = new Label();
                    lblASlNo.Text = (1).ToString();
                    TableCell ASlNo = new TableCell();
                    ASlNo.Controls.Add(lblASlNo);

                    Label lblAName = new Label();
                    lblAName.Text = AadharData.Split('_')[0];
                    TableCell AName = new TableCell();
                    AName.Controls.Add(lblAName);

                    Label lblAGender = new Label();
                    lblAGender.Text = AadharData.Split('_')[2];
                    TableCell Gender = new TableCell();
                    Gender.Controls.Add(lblAGender);

                    Label lblADOB = new Label();
                    lblADOB.Text = AadharData.Split('_')[3];
                    TableCell DOB = new TableCell();
                    DOB.Controls.Add(lblADOB);

                    Label lblAMobileNo = new Label();
                    lblAMobileNo.Text = AadharData.Split('_')[4];
                    TableCell AMobileNo = new TableCell();
                    AMobileNo.Controls.Add(lblAMobileNo);

                    Label lblAAddress = new Label();
                    lblAAddress.Text = AadharData.Split('_')[5];
                    TableCell AAddress = new TableCell();
                    AAddress.Controls.Add(lblAAddress);

                    System.Web.UI.WebControls.Image img = new System.Web.UI.WebControls.Image();
                    img.ImageUrl = tabaws.Rows[0]["PhotoPath"].ToString();
                    img.Width = 200;
                    img.Height = 200;
                    TableCell imgcell = new TableCell();
                    imgcell.Controls.Add(img);


                    AWSrow.Controls.Add(ASlNo);
                    AWSrow.Controls.Add(AName);
                    AWSrow.Controls.Add(Gender);
                    AWSrow.Controls.Add(DOB);
                    AWSrow.Controls.Add(AMobileNo);
                    AWSrow.Controls.Add(AAddress);
                    AWSrow.Controls.Add(imgcell);
                    Table1.Controls.Add(AWSrow);
                }
            }
            else
            {
                lblMsg.Text = "No Record Found";
                lblMsg.ForeColor = System.Drawing.Color.Red;
            }
        }
    }
}