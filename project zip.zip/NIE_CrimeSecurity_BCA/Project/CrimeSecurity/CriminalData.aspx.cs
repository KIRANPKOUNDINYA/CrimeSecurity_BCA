﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace CrimeSecurity
{
    public partial class CriminalData : System.Web.UI.Page
    {
        static string CriminalId;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                lblMsg.Text = "";
                if (Request.QueryString["CriminalId"] != null)
                {
                    CriminalId = Request.QueryString["CriminalId"].ToString();


                }
                else
                    CriminalId = "0";
            }
        }
        static string filename;
        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (PhotoFile.HasFile)
            {
                Random rnd = new Random();
                MyConnection obj = new MyConnection();
                filename = CriminalId + "_" + rnd.Next(1000, 9999) + Path.GetExtension(PhotoFile.FileName);
                string filepath = "~/PhotoFiles/" + filename;
                PhotoFile.SaveAs(Server.MapPath(filepath));
                string result = obj.AddCriminalData(int.Parse(CriminalId), txtEye.Text, txtFinger.Text, txtHeight.Text, txtWeight.Text, filepath);
                if (result == "1")
                {

                    string Message = "Criminal Id:" + CriminalId;
                    txtEye.Text = txtFinger.Text = txtHeight.Text = txtWeight.Text = "";

                    lblMsg.Text = "Criminal Added Successfully & " + Message;
                    lblMsg.ForeColor = System.Drawing.Color.Green;
                }

                else if (result == "0")
                {

                    txtEye.Text = txtFinger.Text = txtHeight.Text = txtWeight.Text = "";
                    lblMsg.Text = "Criminal Creation Error";
                    lblMsg.ForeColor = System.Drawing.Color.Red;
                }
            }
        }
    }
}