﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using ZXing;
using System.Drawing;
using System.Drawing.Imaging;
using Amazon.S3;
using Amazon.S3.Model;
using System.Text;
using System.IO;

namespace CrimeSecurity
{
    public partial class ApproveAadharRequest : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Panel1.Visible = false;
                Panel2.Visible = false;
            }

            LoadData();
        }

        private void LoadData()
        {
            try
            {
                MyConnection obj = new MyConnection();
                DataTable tab = new DataTable();

                tab = obj.GetAadharData();
                Table1.Controls.Clear();
                if (tab.Rows.Count > 0)
                {
                    Panel1.Visible = true;
                    Panel2.Visible = true;
                    TableRow hr = new TableRow();
                    TableHeaderCell hc1 = new TableHeaderCell();
                    TableHeaderCell hc2 = new TableHeaderCell();
                    TableHeaderCell hc3 = new TableHeaderCell();
                    TableHeaderCell hc4 = new TableHeaderCell();
                    TableHeaderCell hc5 = new TableHeaderCell();
                    TableHeaderCell hc6 = new TableHeaderCell();
                    TableHeaderCell hc7 = new TableHeaderCell();


                    hc1.Text = "Sl No";
                    hr.Cells.Add(hc1);
                    hc2.Text = "Name";
                    hr.Cells.Add(hc2);
                    hc3.Text = "Request Date";
                    hr.Cells.Add(hc3);
                    hc4.Text = "Reason";
                    hr.Cells.Add(hc4);
                    hc5.Text = "";
                    hr.Cells.Add(hc5);
                    hc6.Text = "";
                    hr.Cells.Add(hc6);
                    hc7.Text = "";
                    hr.Cells.Add(hc7);


                    Table1.Rows.Add(hr);
                    for (int i = 0; i < tab.Rows.Count; i++)
                    {
                        TableRow row = new TableRow();

                        Label lblSlNo = new Label();
                        lblSlNo.Text = (i + 1).ToString();
                        TableCell SlNo = new TableCell();
                        SlNo.Controls.Add(lblSlNo);

                        Label lblName = new Label();
                        lblName.Text = tab.Rows[i]["Name"].ToString();
                        TableCell Name = new TableCell();
                        Name.Controls.Add(lblName);

                        Label lbllogDate = new Label();
                        lbllogDate.Text = tab.Rows[i]["ReqDate"].ToString();
                        TableCell logDate = new TableCell();
                        logDate.Controls.Add(lbllogDate);

                        Label lblReqReason = new Label();
                        lblReqReason.Text = tab.Rows[i]["ReqReason"].ToString();
                        TableCell ReqReason = new TableCell();
                        ReqReason.Controls.Add(lblReqReason);

                        LinkButton View = new LinkButton();
                        View.Text = "Request User";
                        View.ID = "lnkView" + i.ToString();
                        View.CommandArgument = tab.Rows[i]["UserId"].ToString();
                        View.Click += new EventHandler(View_Click);

                        TableCell ViewCell = new TableCell();
                        ViewCell.Controls.Add(View);

                        LinkButton Approve = new LinkButton();
                        Approve.Text = "Approve";
                        Approve.ID = "lnkApprove" + i.ToString();
                        Approve.CommandArgument = tab.Rows[i]["ReqId"].ToString();
                        Approve.Click += new EventHandler(Approve_Click);

                        TableCell ApproveCell = new TableCell();
                        ApproveCell.Controls.Add(Approve);

                        LinkButton Reject = new LinkButton();
                        Reject.Text = "Reject";
                        Reject.ID = "lnkReject" + i.ToString();
                        Reject.CommandArgument = tab.Rows[i]["ReqId"].ToString();
                        Reject.Click += new EventHandler(Reject_Click);

                        TableCell RejectCell = new TableCell();
                        RejectCell.Controls.Add(Reject);



                        row.Controls.Add(SlNo);
                        row.Controls.Add(Name);
                        row.Controls.Add(logDate);
                        row.Controls.Add(ReqReason);
                        row.Controls.Add(ViewCell);
                        row.Controls.Add(ApproveCell);
                        row.Controls.Add(RejectCell);
                        Table1.Controls.Add(row);

                    }
                }
                else
                {
                    //lblMsg.Text = "No Record Found";
                }
            }
            catch
            {

            }
        }

        void Reject_Click(object sender, EventArgs e)
        {
            LinkButton lnk = (LinkButton)sender;
            int ReqId = int.Parse(lnk.CommandArgument);
            MyConnection obj = new MyConnection();
            string result = obj.AadharReq_AR(ReqId, "Reject");
            if (result == "1")
            {
                LoadData();
            }
        }

        void Approve_Click(object sender, EventArgs e)
        {
            LinkButton lnk = (LinkButton)sender;
            int ReqId = int.Parse(lnk.CommandArgument);
            MyConnection obj = new MyConnection();
            string result = obj.AadharReq_AR(ReqId, "Approve");
            if (result == "1")
            {
                LoadData();
            }
        }
        AmazonS3Client _s3ClientObj = null;
        void View_Click(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            LinkButton lnk = (LinkButton)sender;
            int UserId = int.Parse(lnk.CommandArgument);
            MyConnection obj = new MyConnection();
            DataTable tab = new DataTable();
            tab = obj.GetUserDetails(UserId);

            Table2.Controls.Clear();
            if (tab.Rows.Count > 0)
            {
                TableRow hr = new TableRow();
                TableHeaderCell hc1 = new TableHeaderCell();
                TableHeaderCell hc2 = new TableHeaderCell();
                TableHeaderCell hc3 = new TableHeaderCell();
                TableHeaderCell hc4 = new TableHeaderCell();

                hc1.Text = "Sl No";
                hr.Cells.Add(hc1);
                hc2.Text = "Name";
                hr.Cells.Add(hc2);
                hc3.Text = "MobileNo";
                hr.Cells.Add(hc3);
                hc4.Text = "Address";
                hr.Cells.Add(hc4);

                Table2.Rows.Add(hr);
                for (int i = 0; i < tab.Rows.Count; i++)
                {
                    TableRow row = new TableRow();

                    Label lblSlNo = new Label();
                    lblSlNo.Text = (i + 1).ToString();
                    TableCell SlNo = new TableCell();
                    SlNo.Controls.Add(lblSlNo);

                    Label lblName = new Label();
                    lblName.Text = tab.Rows[i]["Name"].ToString();
                    TableCell Name = new TableCell();
                    Name.Controls.Add(lblName);

                    Label lblMobileNo = new Label();
                    lblMobileNo.Text = tab.Rows[i]["MobileNo"].ToString();
                    TableCell MobileNo = new TableCell();
                    MobileNo.Controls.Add(lblMobileNo);

                    Label lblAddress = new Label();
                    lblAddress.Text = tab.Rows[i]["Address"].ToString();
                    TableCell Address = new TableCell();
                    Address.Controls.Add(lblAddress);


                    row.Controls.Add(SlNo);
                    row.Controls.Add(Name);
                    row.Controls.Add(MobileNo);
                    row.Controls.Add(Address);
                    Table2.Controls.Add(row);

                }
            }
            else
            {
                //lblMsg.Text = "No Record Found";
            }

            obj = new MyConnection();
            DataTable tabaws = new DataTable();
            tabaws = obj.GetUserAadharAWS(tab.Rows[0]["AadharNo"].ToString());

            _s3ClientObj = new AmazonS3Client("AKIA2PAQROQSWPFRCBEY", "tjrNzQwPc55MOxbAsyCfmqKeNjKqS+VJs4I7F+Ni", Amazon.RegionEndpoint.USEast1);
            string fname = "~/DownloadFile/" + tabaws.Rows[0]["AWSFilePath"].ToString().Split('/')[1];
            if (File.Exists(Server.MapPath(fname)))
            {
                File.Delete(Server.MapPath(fname));
            }
            GetObjectResponse _responseObj = _s3ClientObj.GetObject(new GetObjectRequest() { BucketName = tabaws.Rows[0]["AWSFilePath"].ToString().Split('/')[0], Key = tabaws.Rows[0]["AWSFilePath"].ToString().Split('/')[1] });
            _responseObj.WriteResponseStreamToFile(Server.MapPath(fname));


            var QCreader = new BarcodeReader();
            string QCfilename = Path.Combine(Server.MapPath(fname));
            var QCresult = QCreader.Decode(new Bitmap(QCfilename));

            string AadharData = AESCryptoClass.Decrypt(QCresult.Text, tabaws.Rows[0]["DataKey"].ToString());

            Table3.Controls.Clear();

            TableRow AWShr = new TableRow();
            TableHeaderCell AWShc1 = new TableHeaderCell();
            TableHeaderCell AWShc2 = new TableHeaderCell();
            TableHeaderCell AWShc3 = new TableHeaderCell();
            TableHeaderCell AWShc4 = new TableHeaderCell();

            AWShc1.Text = "Sl No";
            AWShr.Cells.Add(AWShc1);
            AWShc2.Text = "Name";
            AWShr.Cells.Add(AWShc2);
            AWShc3.Text = "MobileNo";
            AWShr.Cells.Add(AWShc3);
            AWShc4.Text = "Address";
            AWShr.Cells.Add(AWShc4);

            Table3.Rows.Add(AWShr);
            TableRow AWSrow = new TableRow();

            Label lblASlNo = new Label();
            lblASlNo.Text = (1).ToString();
            TableCell ASlNo = new TableCell();
            ASlNo.Controls.Add(lblASlNo);

            Label lblAName = new Label();
            lblAName.Text = AadharData.Split('_')[0];
            TableCell AName = new TableCell();
            AName.Controls.Add(lblAName);

            Label lblAMobileNo = new Label();
            lblAMobileNo.Text = AadharData.Split('_')[4];
            TableCell AMobileNo = new TableCell();
            AMobileNo.Controls.Add(lblAMobileNo);

            Label lblAAddress = new Label();
            lblAAddress.Text = AadharData.Split('_')[5];
            TableCell AAddress = new TableCell();
            AAddress.Controls.Add(lblAAddress);


            AWSrow.Controls.Add(ASlNo);
            AWSrow.Controls.Add(AName);
            AWSrow.Controls.Add(AMobileNo);
            AWSrow.Controls.Add(AAddress);
            Table3.Controls.Add(AWSrow);


        }

        
    }
}