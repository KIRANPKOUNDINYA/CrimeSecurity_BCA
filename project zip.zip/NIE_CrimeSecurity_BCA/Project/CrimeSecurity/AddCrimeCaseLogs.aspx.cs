﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using ZXing;
using System.Drawing;
using System.Drawing.Imaging;
using Amazon.S3;
using Amazon.S3.Model;
using System.IO;

namespace CrimeSecurity
{
    public partial class AddCrimeCaseLogs : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                MyConnection obj = new MyConnection();
                DataTable tab = new DataTable();
                tab = obj.GetCrime(int.Parse(Session["UserId"].ToString()));
                ddlCrime.DataSource = tab;
                ddlCrime.DataTextField = "CrimeName";
                ddlCrime.DataValueField = "CrimeId";
                ddlCrime.DataBind();
                ddlCrime.Items.Insert(0, "--Select--");
            }
        }
        AmazonS3Client _s3ClientObj = null;
        static string filename;
        protected void btnSave_Click(object sender, EventArgs e)
        {
            MyConnection obj = new MyConnection();
            string logdate = DateTime.Now.ToString();
            Random rnd = new Random();
            int key = rnd.Next(1000, 9999);

            string EncryptData = AESCryptoClass.EncryptData(txtCaseSummary.Text, key.ToString());

            Random rnd1 = new Random();
            var QCwriter = new BarcodeWriter();
            QCwriter.Format = BarcodeFormat.QR_CODE;
            var result = QCwriter.Write(EncryptData);
            string v = rnd1.Next(1000, 9999).ToString();
            filename = ddlCrime.SelectedItem.Text + "_" + v + ".jpg";

            string filepath = "~/CrimeRecord/" + filename;
            var barcodeBitmap = new Bitmap(result);

            using (MemoryStream memory = new MemoryStream())
            {
                using (FileStream fs = new FileStream(Server.MapPath(filepath),
                   FileMode.Create, FileAccess.ReadWrite))
                {
                    barcodeBitmap.Save(memory, ImageFormat.Jpeg);
                    byte[] bytes = memory.ToArray();
                    fs.Write(bytes, 0, bytes.Length);
                }
            }



            ////Amazon AWS 
            _s3ClientObj = new AmazonS3Client("AKIA2PAQROQSWPFRCBEY", "tjrNzQwPc55MOxbAsyCfmqKeNjKqS+VJs4I7F+Ni", Amazon.RegionEndpoint.USEast1);
            PutBucketRequest p1 = new PutBucketRequest();
            p1.BucketName = "crimecase" + ddlCrime.SelectedItem.Value; // reason: bucket name shared by millions so to avoid naming conflict , u can give anything u want
            _s3ClientObj.PutBucket(p1);

            PutObjectRequest _requestObj = new PutObjectRequest();
            _requestObj.BucketName = "crimecase" + ddlCrime.SelectedItem.Value;
            _requestObj.FilePath = Server.MapPath(filepath);
            PutObjectResponse _responseObj = _s3ClientObj.PutObject(_requestObj);

            if (_responseObj.HttpStatusCode == System.Net.HttpStatusCode.OK)
            {
                string FilePath = "crimecase" + ddlCrime.SelectedItem.Value + "/" + filename;
                obj = new MyConnection();
                string res = obj.CreateTable_CSL(int.Parse(ddlCrime.SelectedItem.Value), logdate, key.ToString(), FilePath);
                if (res == "1")
                {

                    ddlCrime.SelectedIndex = 0;
                    txtCaseSummary.Text = "";
                    lblMsg.Text = "Crime Log Table Created Successfully";
                    lblMsg.ForeColor = System.Drawing.Color.Green;
                }

                else if (res == "0")
                {
                    // txtName.Text = txtCrimePlace.Text = "";
                    lblMsg.Text = "Crime Table Creation Error";
                    lblMsg.ForeColor = System.Drawing.Color.Red;
                }
            }
        }
    }
}